import pandas as pd
import statistics

def load_stock_data(file_path):
    xls = pd.ExcelFile(file_path)
    stock_data = pd.read_excel(xls, sheet_name="IRCTC Stock Price")
    stock_data["Date"] = pd.to_datetime(stock_data.iloc[:, 0])
    stock_data["Day"] = stock_data["Date"].dt.day_name()
    return stock_data

def calculate_price_statistics(stock_data):
    mean_price = statistics.mean(stock_data.iloc[:, 3])
    variance_price = statistics.variance(stock_data.iloc[:, 3])
    return mean_price, variance_price

def analyze_wednesday_prices(stock_data):
    wednesday_prices = stock_data[stock_data["Day"] == "Wednesday"].iloc[:, 3]
    sample_mean_wed = statistics.mean(wednesday_prices)
    return sample_mean_wed

def calculate_probabilities(stock_data):
    chg_percent = stock_data.iloc[:, 8].dropna()
    prob_loss = sum(1 for x in chg_percent if x < 0) / len(chg_percent)
    wednesday_chg = stock_data[stock_data["Day"] == "Wednesday"].iloc[:, 8].dropna()
    prob_profit_wed = sum(1 for x in wednesday_chg if x > 0) / len(wednesday_chg)
    prob_profit_given_wed = prob_profit_wed / prob_loss if prob_loss != 0 else 0
    return prob_loss, prob_profit_wed, prob_profit_given_wed

if __name__ == "__main__":
    file_path = "/Users/lalithmachavarapu/Downloads/Lab Session Data.xlsx"  # Update with the correct path
    stock_data = load_stock_data(file_path)
    mean_price, variance_price = calculate_price_statistics(stock_data)
    sample_mean_wed = analyze_wednesday_prices(stock_data)
    prob_loss, prob_profit_wed, prob_profit_given_wed = calculate_probabilities(stock_data)
    
    print("Mean Price:", mean_price)
    print("Variance of Price:", variance_price)
    print("Sample Mean (Wednesday):", sample_mean_wed)
    print("Probability of Loss:", prob_loss)
    print("Probability of Profit on Wednesday:", prob_profit_wed)
    print("Conditional Probability of Profit given Wednesday:", prob_profit_given_wed)