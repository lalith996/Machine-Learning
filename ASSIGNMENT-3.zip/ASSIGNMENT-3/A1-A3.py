import pandas as pd
import numpy as np

# Load the Excel file
file_path = "/Users/lalithmachavarapu/Downloads/Lab Session Data.xlsx"
xls = pd.ExcelFile(file_path)

# Load the "Purchase data" sheet
purchase_data = pd.read_excel(xls, sheet_name="Purchase data")

# Select relevant columns: Product quantities and Payments
purchase_data_clean = purchase_data.iloc[:, :5].dropna()
purchase_data_clean.columns = ["Customer", "Candies", "Mangoes", "Milk_Packets", "Payment"]

# Extract matrices A (product quantities) and C (payment)
A = purchase_data_clean.iloc[:, 1:4].values  # Independent variables (quantities)
C = purchase_data_clean.iloc[:, 4].values    # Dependent variable (payment)

# Get dimensions of vector space
dimensionality = A.shape[1]  # Number of independent variables (features)
num_vectors = A.shape[0]      # Number of observations (customers)

# Compute rank of matrix A
rank_A = np.linalg.matrix_rank(A)

# Compute pseudo-inverse and find cost per product
pseudo_inverse_A = np.linalg.pinv(A)
X = pseudo_inverse_A @ C  # Model vector for product cost

print("Dimensionality:", dimensionality)
print("Number of Vectors:", num_vectors)
print("Rank of Matrix A:", rank_A)
print("Cost per Product (Candies, Mangoes, Milk Packets):", X)
# Model vector X is already calculated in A1 using pseudo-inverse
print("Model Vector X:", X)
# Classify customers based on payment threshold of Rs. 200
purchase_data_clean["Class"] = ["RICH" if p > 200 else "POOR" for p in purchase_data_clean["Payment"]]

# Display classified data
print(purchase_data_clean[["Customer", "Payment", "Class"]])
