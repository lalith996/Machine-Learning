import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics.pairwise import cosine_similarity

def load_data(file_path, sheet_name):
    return pd.read_excel(file_path, sheet_name=sheet_name)

def explore_data(df):
    data_types = df.dtypes
    missing_values = df.isnull().sum()
    df_numeric = df.select_dtypes(include=['number'])
    Q1 = df_numeric.quantile(0.25)
    Q3 = df_numeric.quantile(0.75)
    IQR = Q3 - Q1
    outliers = ((df_numeric < (Q1 - 1.5 * IQR)) | (df_numeric > (Q3 + 1.5 * IQR))).sum()
    stats_summary = df_numeric.describe()
    return data_types, missing_values, outliers, stats_summary

def impute_missing_values(df):
    for col in df.columns:
        if df[col].dtype == "object":
            df[col].fillna(df[col].mode()[0], inplace=True)
        else:
            df[col].fillna(df[col].median(), inplace=True)
    return df

def normalize_data(df):
    num_cols = df.select_dtypes(include=['float64', 'int64']).columns
    scaler = MinMaxScaler()
    df[num_cols] = scaler.fit_transform(df[num_cols])
    return df

def compute_similarity_measures(df):
    
    binary_attributes = df.iloc[:, :5].apply(pd.to_numeric, errors='coerce').fillna(0)
    binary_attributes = binary_attributes.applymap(lambda x: 1 if x > 0 else 0)
    
    if len(binary_attributes) < 2:
        return None, None, None
    
    v1, v2 = binary_attributes.iloc[0], binary_attributes.iloc[1]
    f11 = sum((v1 == 1) & (v2 == 1))
    f00 = sum((v1 == 0) & (v2 == 0))
    f01 = sum((v1 == 0) & (v2 == 1))
    f10 = sum((v1 == 1) & (v2 == 0))
    
    jaccard_coeff = f11 / (f01 + f10 + f11) if (f01 + f10 + f11) > 0 else 0
    smc_coeff = (f11 + f00) / (f00 + f01 + f10 + f11)
    
    cosine_sim = cosine_similarity([binary_attributes.iloc[0]], [binary_attributes.iloc[1]])[0][0]
    
    return jaccard_coeff, smc_coeff, cosine_sim

def generate_heatmap(df):
    subset_size = min(20, len(df))
    
    binary_subset = df.iloc[:subset_size, :5].apply(pd.to_numeric, errors='coerce').fillna(0)
    binary_subset = binary_subset.applymap(lambda x: 1 if x > 0 else 0)
    
    jaccard_matrix = np.zeros((subset_size, subset_size))
    smc_matrix = np.zeros((subset_size, subset_size))
    cosine_matrix = np.zeros((subset_size, subset_size))
    
    for i in range(subset_size):
        for j in range(subset_size):
            v1, v2 = binary_subset.iloc[i], binary_subset.iloc[j]
            f11 = sum((v1 == 1) & (v2 == 1))
            f00 = sum((v1 == 0) & (v2 == 0))
            f01 = sum((v1 == 0) & (v2 == 1))
            f10 = sum((v1 == 1) & (v2 == 0))
            
            denom = f01 + f10 + f11
            jaccard_matrix[i, j] = f11 / denom if denom > 0 else 0
            smc_matrix[i, j] = (f11 + f00) / (f00 + f01 + f10 + f11)
            cosine_matrix[i, j] = cosine_similarity([binary_subset.iloc[i]], [binary_subset.iloc[j]])[0][0]
    
    return jaccard_matrix, smc_matrix, cosine_matrix


file_path = "/Users/lalithmachavarapu/Downloads/Lab Session Data.xlsx"
th_data = load_data(file_path, "thyroid0387_UCI")
data_types, missing_values, outliers, stats_summary = explore_data(th_data)
th_data = impute_missing_values(th_data)
th_data = normalize_data(th_data)
jaccard_coeff, smc_coeff, cosine_sim = compute_similarity_measures(th_data)
jaccard_matrix, smc_matrix, cosine_matrix = generate_heatmap(th_data)


print("Data Types:\n", data_types)
print("Missing Values:\n", missing_values)
print("Outliers:\n", outliers)
print("Statistical Summary:\n", stats_summary)
print("Jaccard Coefficient:", jaccard_coeff)
print("Simple Matching Coefficient:", smc_coeff)
print("Cosine Similarity:", cosine_sim)


plt.figure(figsize=(12, 4))
sns.heatmap(jaccard_matrix, annot=False, cmap="coolwarm", xticklabels=False, yticklabels=False)
plt.title("Jaccard Coefficient Heatmap")
plt.show()

plt.figure(figsize=(12, 4))
sns.heatmap(smc_matrix, annot=False, cmap="coolwarm", xticklabels=False, yticklabels=False)
plt.title("Simple Matching Coefficient Heatmap")
plt.show()

plt.figure(figsize=(12, 4))
sns.heatmap(cosine_matrix, annot=False, cmap="coolwarm", xticklabels=False, yticklabels=False)
plt.title("Cosine Similarity Heatmap")
plt.show()