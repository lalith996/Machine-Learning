import numpy as np
import matplotlib.pyplot as plt
V1=np.random.rand(100)
V1.sort()
print(V1)#1
print(V1*3)
Avg=V1.mean()
print(Avg)
diff=[]
sum=0
for i in range(100):
    d=V1[i]-Avg
    sum=sum+d**2
S_D=(sum/100)**0.5
print(S_D)
plt.plot(V1, color='red', label="V1")
V2 = V1**2
plt.plot(V2, color='blue', label="V2")
plt.xlabel('Index')
plt.ylabel('Value')
plt.title('Plot of V1 and V2')
plt.legend()
plt.show()