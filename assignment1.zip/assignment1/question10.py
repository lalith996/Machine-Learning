import pandas as pd
input_file = 'question10.xlsx' 
df = pd.read_excel(input_file)
df['City & State'] = df['City'] + ', ' + df['State']
output_file = 'result.xlsx'
df.to_excel(output_file, index=False)
print(df)
