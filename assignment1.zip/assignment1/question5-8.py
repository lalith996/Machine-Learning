str1= "I am a great learner.I am going to have an awesome life."
count=0
for i in range(len(str1)-1):
    if str1[i]+str1[i+1]=="am":
        count+=1
print(count)#5
str2= "I work hard and shall be rewarded well."
str3=str1+str2
print(str3)#6
array=[]
start=0
for i in range(len(str3)):
    if str3[i]==" " or str3[i]==".":
        word=str3[start:i]
        array.append(word)
        start=i+1
print(len(array))#7
new_array=[]
words=["I","am","to","and"]
for i in array:
    if i not in words and len(i)<6:
        new_array.append(i)
print(len(new_array))#8

