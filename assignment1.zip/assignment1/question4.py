import numpy as np
A=np.zeros((4,3))
A=np.random.rand(4,3)
print(A)
print(A.flatten())