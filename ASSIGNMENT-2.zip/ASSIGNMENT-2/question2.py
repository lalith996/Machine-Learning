def matrix_maltiplication(A,B):
    C=[[0]*b_c for _ in range(a_r)]
    if a_r==b_c:
      for i in range(a_r):
        for j in range(b_c):
            for k in range(a_c):
                C[i][j]+=A[j][k]*B[k][j]
    else:
        print("error")
    return C
a_r=int(input("enter the no of rows in matrix A:"))
a_c=int(input("enter the no of cols in matrix A:"))
print("enter the entries of matrix A :")
A=([[int(input()) for x in range(a_c)] for y in range(a_r)])
b_r=int(input("enter the no of rows in matrix B:"))
b_c=int(input("enter the no of cols in matrix B:"))
print("enter the entries of matrix B: ")
B=([[int(input()) for x in range(b_c)] for y in range(b_r)])
print(A,"\n",B)
C=matrix_maltiplication(A,B)
print("Result matrix :",C)