def common_elements(A,B):
    count=0
    for i in range(5):
     for j in range(5):
        if A[i]==B[j]:
            count+=1
    return count
print("enter entries in list 1:")
A=[int(input()) for x in range(5)]
print("enter entries in list 2:")
B=[int(input()) for x in range(5)]
print("no of common elements",common_elements(A,B))
