def transpose(A):
    A_t=[[0]*a_r for _ in range(a_c)]
    for i in range(a_r):
        for j in range(a_c):
                A_t[j][i]+=A[i][j]
    return A_t
a_r=int(input("enter the no of rows in matrix A:"))
a_c=int(input("enter the no of cols in matrix A:"))
print("enter the entries of matrix A :")
A=([[int(input()) for x in range(a_c)] for y in range(a_r)])
print("Original matrix :",A)
print("Transpose  matrix :",transpose(A))