
def no_of_v_and_C(S):
    vowel_count=0
    consonant_count=0
    for i in s:
     if(i=="a")or(i=="e")or(i=="i")or(i=="o")or(i=="u"):
         vowel_count+=1
     else:
         consonant_count+=1
    return vowel_count,consonant_count

s=str(input())
vowel_count,consonant_count=no_of_v_and_C(s)
print("vowel_count :",vowel_count,"\nconsonant_count :",consonant_count)